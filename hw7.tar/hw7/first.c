#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node{
    int data;//input that is either 0 or 1
    char name[11];//variable name
    struct Node* next;
} Node;

void push(FILE* f, Node** start){//used when the list is null
     Node* newNode = (Node*)malloc(sizeof(Node));
     fscanf(f, "%s ", newNode->name);
     newNode->next = (*start);
     (*start) = newNode;
}

void addNode(FILE* f, Node* prev){//adds an element at the end of a list
     Node* newNode = (Node*)malloc(sizeof(Node));
     fscanf(f, "%s ", newNode->name);
     newNode->next = NULL;
     prev->next = newNode;
}

void freeNode(Node* head){//frees lists of nodes
    Node* tmp;    
    while(head != NULL){
        tmp = head;      
        head = head->next;
        free(tmp);      
    }
}

int get(int x, int n){//gets the nth bit of a bitwise string
    x = x & (1 << n);
    if(x == 0){
        return 0;
    }else{
        return 1;
    }
}

int getVariable(Node* head, char s[]){//get a specific input
    Node* variable = head;

    while(variable != NULL){
        if(strcmp(variable->name, s) == 0){
            return variable->data;
        }
        variable = variable->next;
    }
    return 2;//returns 2 since possible values are only 0 and 1
}

int blocks(char block[], int input1, int input2){//function for block operations
    int outputdata = 0;
    if(strcmp(block, "NOT") == 0){
        outputdata = !(input1);
    }else if(strcmp(block, "AND") == 0){
        outputdata = input1 & input2;
    }else if(strcmp(block, "OR") == 0){
        outputdata = input1 | input2;
    }else if(strcmp(block, "NAND") == 0){
        outputdata = !(input1 & input2);
    }else if(strcmp(block, "NOR") == 0){
        outputdata = !(input1 | input2);
    }else if(strcmp(block, "XOR") == 0){
        outputdata = input1 ^ input2;
    }
    return outputdata;
}

int main(int argc, char* argv[])
{
    FILE* fp = fopen(argv[1], "r");

    char str[10];//string for INPUTVAR and OUTPUTVAR
    int inputsize;//number of given inputs
    int outputsize;//number of given outputs

    fscanf(fp, "%s ", str);
    fscanf(fp, "%d ", &inputsize);

    Node* input = NULL;//list of inputs
    int counter = 0;//variable for iteration through loops
    while(counter < inputsize){
        if(input == NULL){
            push(fp, &input);           
        }else{            
            Node* crnt = input;
            while(crnt->next != NULL){
                crnt = crnt->next;
            }
            addNode(fp, crnt);
        }        
        counter++;       
    }
    
    counter = 0;
    fscanf(fp, "%s ", str);
    fscanf(fp, "%d ", &outputsize);

    Node* output = NULL;//list of outputs
    while(counter < outputsize){
        if(output == NULL){
            push(fp, &output);
        }else{
            Node* crnt2 = output;
            while(crnt2->next != NULL){
                crnt2 = crnt2->next;
            }
            addNode(fp, crnt2);
        }
        counter++;        
    }
  
    counter = 0;
    int outcomes = 2;
    for(int t = 1; t < inputsize; t++){//sets up the number of possible outcomes
            outcomes = outcomes*2;
    }

    unsigned long position = ftell(fp);//position in fp that marks the beginning of the block operations

    while(counter < outcomes){
        Node* temps = NULL;//list of temporary variables
        Node* adddata = input;
        int size = inputsize - 1;
        while(adddata != NULL){//sets up the integers for each input variable
            adddata->data = get(counter, size);
            size--;
            adddata = adddata->next;
        }
        int* outdata;//address to the output where we store our data
        while(1){
            char operator[5];//block operation
            char in1[11];//first input
            char in2[11];//second input
            char out[11];//output
            int c = fscanf(fp, "%s ", operator);
            if(c != 1){
                break;
            }
            fscanf(fp, "%s ", in1);
            if(strcmp(operator, "NOT") != 0){
                fscanf(fp, "%s ", in2);
            }
            fscanf(fp, "%s ", out);

            int in1data = getVariable(input, in1);//data of our first input
            int in2data = getVariable(input, in2);//data of our second input

            Node* getOutput = output;//checks whether we are pulling from output or creating a temporary variable
            while(getOutput != NULL){
                if(strcmp(out, getOutput->name) == 0){//checks output for the appropriate value
                    outdata = &(getOutput->data);
                    break;
                }
                if(getOutput->next == NULL){//variable not present in output, therefore we create a temporary variable
                    Node* newNode = (Node*)malloc(sizeof(Node));
                    outdata = &(newNode->data);
                    strcpy(newNode->name, out);                   
                    if(temps == NULL){
                        Node** start = &temps;
                        newNode->next = (*start);
                        (*start) = newNode;           
                    }else{            
                        Node* crnt3 = temps;
                        while(crnt3->next != NULL){
                             crnt3 = crnt3->next;
                        }
                        newNode->next = NULL;
                        crnt3->next = newNode;
                    }        
                }
                getOutput = getOutput->next;
            }
            if((in1data == 2) || (in2data == 2)){//checks whether any of our inputs are temporary variables
                Node* check = temps;
                while(check != NULL){
                    if(strcmp(in1, check->name) == 0){
                        in1data = check->data;
                    }
                    if(strcmp(in2, check->name) == 0){
                        in2data = check->data;
                    }
                    check = check->next;
                }
            }
            *outdata = blocks(operator, in1data, in2data);//performs the block operation and sets our outputs
        }

        //prints out the inputs and outputs for each outcome
        Node* printin = input;
        while(printin != NULL){
            printf("%d ", printin->data);
            printin = printin->next;
        }
        Node* printout = output;
        while(printout != NULL){
            printf("%d ", printout->data);
            printout = printout->next;
        }
        printf("\n");
        counter++;
        freeNode(temps);
        fseek(fp, position, SEEK_SET);//jumps back to the beginning of the block operations
    }

    freeNode(input);
    freeNode(output);
    
    fclose(fp);
}
