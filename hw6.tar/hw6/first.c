#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Block{
    int tag;//tag for the block
    int accessed;//used for lru that signifies when it was recently accessed
    int added;//used for fifo that signifies when it was recently added
    int capacity;//indicator that shows how many blocks are in the set
    struct Block* next;    
} Block;

Block* addBlock(Block* b, int tag, int c){//add a block to a set
    Block* newBlock = (Block*)malloc(sizeof(Block));
    newBlock->tag = tag;
    newBlock->next = b;
    newBlock->capacity = c;
    return newBlock;
}

int getPower(int x){
    int power;
    for(int i = 0; i < 31; i++){
        if((x >> i) == 1){
            power = i;
            break;
        }
    }
    return power;
}

int isPower2(int x){
    for(int i = 0; i < 31; i++){
        if(x == 1 << i){
            return 1;
        }
    }
    return 0;
}

int valid(int cache, char* a, char* r, int block){//checks if the parameters are valid, returns the number of lines for each set
    
    if(isPower2(cache) == 0){
        return 0;
    }
    
    if(isPower2(block) == 0){
        return 0;
    }

    if((strcmp(r, "lru") != 0) && (strcmp(r, "fifo") != 0)){
        return 0;
    }
    
    if(strcmp(a, "direct") == 0){
        return 1;
    }else if(strncmp(a, "assoc:", 6) == 0){        
        int size = atoi(a+6);       
        
        if(isPower2(size) == 0){
            return 0;
        }
        return size;
    }else if(strcmp(a, "assoc") == 0){
        return block;
    }
    return 1;
}

int main(int argc, char* argv[])
{
    int cachesize = atoi(argv[1]);
    char* associativity = argv[2];
    char* replace = argv[3];
    int blocksize = atoi(argv[4]);
    FILE* fp = fopen(argv[5], "r");

    int setSize;//number of lines in each set

    char pc[20];//program counter
    char mode;//indicator for a read or write
    int address;//memory address
    
    int blockMask, setMask, tagMask;
       
    if(valid(cachesize, associativity, replace, blocksize) == 0){
        printf("error\n");
        exit(0);
    }else{
        setSize = valid(cachesize, associativity, replace, blocksize);       
    }
    int numSets = (cachesize/blocksize)/setSize;//number of sets in our cache
    
    int blockBits = getPower(blocksize);//number of bits in a block
    int setBits = getPower(numSets);//number of bits in a set

    Block* cache[numSets];//main cache

    for(int b = 0; b < numSets; b++){//allocate space for cache
        cache[b] = (Block*)malloc(setSize*sizeof(Block));
        cache[b]->capacity = 0;
    }

    int reads = 0; 
    int writes = 0;
    int hits = 0;
    int misses = 0;
    int accesses = 0;//counter for lru
    int additions = 0;//counter for fifo

    while(1){
        fscanf(fp, "%s %c %x", pc, &mode, &address);
        if(strcmp(pc, "#eof") == 0){
            break;
        }
        
        //masks that help us find our set and tag values
        blockMask = blocksize - 1;
        setMask = (numSets - 1) << blockBits;
        tagMask = -1^setMask^blockMask;
        
        int set = (address & setMask) >> blockBits;
        int tag = ((address & tagMask) >> blockBits) >> setBits;
        int alreadyhit = 0;//indicator that shows we have hit the cache
        if(cache[set]->capacity != 0){//checks if we have hit the cache
            Block* temp = cache[set];
            while(temp != NULL){
                if(tag == temp->tag){
                    hits++;
                    if(mode == 'W'){
                        writes++;
                    }
                    accesses++;
                    temp->accessed = accesses;
                    alreadyhit++;
                    break;
                }
                temp = temp->next;
            }                     
        }
        if(alreadyhit == 0){//we have missed the cache
            misses++;  
 
            if(cache[set]->capacity == 0){//cold miss        
                cache[set]->tag = tag;
                cache[set]->capacity += 1;
                accesses++;
                additions++;
                cache[set]->accessed = accesses;
                cache[set]->added = additions;
                cache[set]->next = NULL;
            }else if(cache[set]->capacity < setSize){
                cache[set] = addBlock(cache[set], tag, cache[set]->capacity);                
                cache[set]->capacity += 1;
                accesses++;
                additions++;
                cache[set]->accessed = accesses;
                cache[set]->added = additions;
            }else if(cache[set]->capacity == setSize){//conflict miss
                Block* newTag = cache[set];
                if(strcmp(replace, "lru") == 0){//replace policy for lru
                    Block* evict = cache[set]->next;
                    int location = cache[set]->accessed;
                    while(evict != NULL){
                        if(evict->accessed < location){
                            location = evict->accessed;
                            newTag = evict;
                        }
                        evict = evict->next;
                    }
                    newTag->tag = tag;
                    accesses++;
                    newTag->accessed = accesses;
                }else if(strcmp(replace, "fifo") == 0){//replace policy for fifo
                    Block* firstout = cache[set]->next;
                    int oldest = cache[set]->added;
                    while(firstout != NULL){
                        if(firstout->added < oldest){
                            oldest = firstout->added;
                            newTag = firstout;
                        }
                        firstout = firstout->next;                        
                    }
                    newTag->tag = tag;
                    additions++;
                    newTag->added = additions;
                }
            }           

            if(mode == 'W'){
                reads++;
                writes++;
            }else{
                reads++;
            }
        }
    }

    printf("Memory reads: %d\n", reads);
    printf("Memory writes: %d\n", writes);
    printf("Cache hits: %d\n", hits);
    printf("Cache misses: %d\n", misses);

    Block* tmp;

    for(int f = 0; f < numSets; f++){
        tmp = cache[f];
        if(tmp->capacity == 0){
            free(cache[f]);
        }else{               
            while(cache[f] != NULL){    
                tmp = cache[f];                                                  
                cache[f] = cache[f]->next;            
                free(tmp);  
            }
        }         
    }       
    
    fclose(fp);
}
