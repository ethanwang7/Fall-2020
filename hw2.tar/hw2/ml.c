/* 
 * 
 * This code calculates the house price of a house by learing from
 * training data. It uses pseudo inverse of a given matrix to find the 
 * weight of different features.
 * 
 * Predicted Price : Y = W0 + W1*x1 + W2*X2 + W3*X3 + W4*X4
 * Weight Matrix : W = pseudoInv(X)*Y
 * pseudoInv(X) = inverse(transpose(X)*X) * transpose(X)  
 * 
 * weight(w) = pseudoInv(X) * Y
 * 			where	X = Input data matrix
 * 					Y = Target vector
 * 
 */
 
#include<stdio.h>
#include<stdlib.h>

// all methods declarations
double** multiplyMatrix(double **matA, double **matB, int r1, int c1, int r2, int c2);
double** transposeMatrix(double** mat, int row, int col);
double** inverseMatrix(double **matA, int dimension);

// main method starts here
int main(int argc, char** argv){
    FILE* f1 = fopen(*(argv + 1), "r");
    FILE* f2 = fopen(*(argv + 2), "r");
    int rows, columns, houses;
    
    fscanf(f1, "%d\n", &columns);
    fscanf(f1, "%d\n", &rows);
    columns++;//making room for W0

    double** trainData = malloc(rows*sizeof(double*));
    double** prices = malloc(rows*sizeof(double*));

    for(int i = 0; i < rows; i++){
        *(trainData + i) = malloc(columns*sizeof(double));
        **(trainData + i) = 1;
        for(int j = 1; j < columns; j++){
            fscanf(f1, "%lf,", &(*(*(trainData + i) + j)));
        }
        *(prices + i) = malloc(sizeof(double));
        fscanf(f1, "%lf\n", &**(prices + i));
    }

    double** transpose = transposeMatrix(trainData, rows, columns);//transpose matrix of trainData

    double** product = multiplyMatrix(transpose, trainData, columns, rows, rows, columns);//product of transpose and trainData

    double** inverse = inverseMatrix(product, columns);//inverse of product

    double** finalProduct = multiplyMatrix(inverse, transpose, columns, columns, columns, rows);//product of inverse and transpose

    double** weight = multiplyMatrix(finalProduct, prices, columns, rows, rows, 1);//product of finalProduct and prices

    fscanf(f2, "%d\n", &houses);
    double* attributes = malloc((columns-1)*sizeof(double));//attributes of a house
         
    for(int k = 0; k < houses; k++){
        double housePrice = **weight;
        for(int h = 0; h < columns-1; h++){
            fscanf(f2, "%lf,", &*(attributes + h));
        }
        for(int w = 1; w < columns; w++){
            housePrice += *(attributes + (w-1)) * *(*(weight+w));
        }
        printf("%0.0lf\n", housePrice);  
    }

    for(int x = 0; x < rows; x++){
        free(*(trainData + x));
        free(*(prices + x));       
    }
    free(trainData);
    free(prices);
    
    for(int y = 0; y < columns; y++){
        free(*(transpose + y));
        free(*(product + y));
        free(*(inverse + y));
        free(*(finalProduct + y));
        free(*(weight + y));       
    }
    free(transpose);
    free(product);
    free(inverse);
    free(finalProduct);
    free(weight);
    free(attributes);
       
	fclose(f1);
    fclose(f2);
	return 0;
}

double** multiplyMatrix(double **matA, double **matB, int r1, int c1, int r2, int c2)
{
    if(c1 != r2){
        return NULL;
    }

    double** result=malloc(r1*sizeof(double*));
    for(int i  = 0; i < r1; i++){
        *(result + i) = calloc(c2, sizeof(double));
    }

    for(int r = 0; r < r2; r++){
        for(int a = 0; a < r1; a++){
            for(int b = 0; b < c2; b++){
                *(*(result + a) + b) += *(*(matA + a) + r) * *(*(matB + r) + b);
            }
        }
    }    
    
    return result;
}


double** transposeMatrix(double** mat, int row, int col)
{
  
	double** matTran=malloc(col*sizeof(double*));
    for(int k = 0; k < col; k++){
       *(matTran + k) = calloc(row, sizeof(double));
    } 

    for(int i = 0; i < col; i++){
        for(int j = 0; j < row; j++){
            *(*(matTran + i) + j) = *(*(mat + j) + i);
        }
    }
    
    return matTran;        
}


double** inverseMatrix(double **matA, int dimension)
{
    
    double** matI=malloc(dimension*sizeof(double*));
    for(int k = 0; k < dimension; k++){
        *(matI + k) = calloc(dimension, sizeof(double));
    } 

    for(int x = 0; x < dimension; x++){
        *(*(matI + x) + x) = 1;                
    }    

    for(int a = 0; a < dimension; a++){          
        if((*(*(matA + a) + a)) == 0){
            break;
        }        
        
        double divisor = *(*(matA + a) + a);
        for(int i = 0; i < dimension; i++){           
            *(*(matA + a) + i) = *(*(matA + a) + i) / divisor;
            *(*(matI + a) + i) = *(*(matI + a) + i) / divisor;           
        }
        
        for(int j = a + 1; j < dimension; j++){
            double ratio = *(*(matA + j) + a);
            
            for(int b = 0; b < dimension; b++){
                *(*(matA + j) + b) = *(*(matA + j) + b) - (ratio * *(*(matA + a) + b));
                *(*(matI + j) + b) = *(*(matI + j) + b) - (ratio * *(*(matI + a) + b));               
            }                        
        }                
    }
    
    for(int z = dimension-1; z >= 0; z--){        
        for(int r = z-1; r >= 0; r--){
            double temp = *(*(matA + r) + z);
            for(int s = 0; s < dimension; s++){                
                *(*(matA + r) + s) = *(*(matA + r) + s) - (temp * *(*(matA + z) + s));               
                *(*(matI + r) + s) = *(*(matI + r) + s) - (temp * *(*(matI + z) + s));
            }           
        }        
    }    
    
	return matI;
}

