#include <stdio.h>
#include <string.h>

int vowelCheck(char c){
    if(c == 'a' || c == 'A' || c == 'e'|| c == 'E' || c == 'i' || c == 'I' || c == 'o' || c == 'O' || c == 'u' || c == 'U'){
        return 1;
    }
    return 0;
}

int main(int argc, char* argv[])
{
    char* str;
    int index = 0;
    for(int i = 1; i < argc; i++){
        str = argv[i];
        while(index < strlen(str)){     
            index++;
        }
    }

    char vowelString[index];
    int count = 0;
    index = 0;

    for(int j = 1; j < argc; j++){
        str = argv[j];
        index = 0;
        while(index < strlen(str)){
            int v = vowelCheck(str[index]);
            if(v == 1){
                vowelString[count] = str[index];
                count++;
            }
            index++;
        }
    }
    vowelString[count] = '\0';
    printf("%s\n", vowelString);
    
}
