#include <stdio.h>
#include<stdlib.h>

typedef struct Node{
    int data;
    struct Node* left;
    struct Node* right;

} Node;

Node* addNode(int d){
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = d;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

Node* insert(Node* node, int d){
    if(node == NULL){
        return addNode(d); 
    }
    
    if(d < node->data){
        node->left = insert(node->left, d);
    }else if(d > node->data){
        node->right = insert(node->right, d);
    }
    
    return node;
}

void traversal(Node* node){
    if(node != NULL){
        traversal(node->left);
        printf("%d\t", node->data);
        traversal(node->right);
    }
}

void freeNodes(Node* node){
    if(node != NULL){
        freeNodes(node->left);       
        freeNodes(node->right);
        free(node);
    }
}

int main(int argc, char* argv[])
{
    FILE* f1 = fopen(argv[1], "r");

    if(f1 == NULL){
        printf("error\n");
        exit(0);
    }

    Node* root = NULL;
    while(1){
        char c;
        int n = fscanf(f1, "%c\t", &c);
        int v;
        fscanf(f1, "%d\n", &v);

        if(n != 1){
            break;
        }
        if(c == 'i'){
            if(root == NULL){
                root = insert(root, v);
            }else{
                insert(root, v);
            }          
        }
    }

    traversal(root);
    printf("\n");
    freeNodes(root);

    fclose(f1);
}
