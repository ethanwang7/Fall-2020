#include <stdio.h>
#include <stdlib.h>

#define MAXSIZE 10000

typedef struct Item{
    int data;
    struct Item* next;
} Item;

int hashCode(int k){
    int temp = k % MAXSIZE;
    if(temp < 0){
        temp = temp + MAXSIZE;
    }

    return temp;

}

Item* search(Item* table[], int k){
    int index = hashCode(k);
    
    Item* node = table[index];
    while(node != NULL){
        if(node->data == k){
            return node;
        }
        node = node->next;
    }
    return NULL;
}

int insert(Item* table[], int d){
    Item* newItem = (Item*)malloc(sizeof(Item));
    newItem->data = d;
    int index = hashCode(d);
    int c = 0;
    if(table[index] != NULL){
        Item* node = table[index];
        while(node->next != NULL){           
            if(node->data == d){
                c++;
                free(newItem);
                return c;
            }
            node = node->next;
        }
        
        newItem->next = NULL;
        node->next = newItem;
        c++;
        return c;
    }

    table[index] = newItem;
    newItem->next = NULL;
    return c;
}

int main(int argc, char* argv[])
{
    FILE* f1 = fopen(argv[1], "r");

    if(f1 == NULL){
        printf("error\n");
        exit(0);
    }

    Item* hashTable[MAXSIZE];
    Item* node;
    int collisions = 0;
    int searches = 0;

    for(int j = 0; j < MAXSIZE; j++){
        hashTable[j] = NULL;
    }
       
    while(1){
        char c;
        int n = fscanf(f1, "%c\t", &c);
        int v;
        fscanf(f1, "%d\n", &v);
        if(n != 1){
            break;
        }
        if(c == 'i'){
            collisions = collisions + insert(hashTable, v);
        }else if(c == 's'){
            node = search(hashTable, v);
            if(node != NULL){
                if(node->data == v){
                    searches++;
                }
            }
        }
    }

    printf("%d\n", collisions);
    printf("%d\n", searches);

    Item* temp;
    for(int i = 0; i < MAXSIZE; i++){               
        while(hashTable[i] != NULL){
            temp = hashTable[i];
            hashTable[i] = hashTable[i]->next;
            free(temp);                                 
        }
    }

    fclose(f1);
}
