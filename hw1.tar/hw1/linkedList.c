#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node* next;
} Node;

void push(Node** start, int d){
     Node* newNode = (Node*)malloc(sizeof(Node));
     newNode->data = d;
     newNode->next = (*start);
     (*start) = newNode;
}

void addNode(Node* prev, int d){
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = d;
    newNode->next = prev->next;
    prev->next = newNode;
}

void delete(Node** start, int d){
    Node* temp = *start;
    Node* prev;
    if((temp != NULL) && (temp->data == d)){
        *start = temp->next; 
        free(temp);           
        return;
    }

    while(temp != NULL){
        if(temp->data == d){
            prev->next = temp->next;
            free(temp);
            return;   
        }
        prev = temp;
        temp = temp->next;
    }
    if(temp == NULL){
        return;
    }
}

int main(int argc, char* argv[])
{   
    FILE* f1 = fopen(argv[1], "r");

    if(f1 == NULL){
        printf("error\n");
        exit(0);
    }

    int size = 0;
    Node* head = NULL;
    
    while(1){ 
        char c;
        int n = fscanf(f1, "%c\t", &c);
        int v;
        fscanf(f1, "%d\n", &v); 
               
        if(n != 1){
            break;
        }
        if(c == 'i'){                   
            if((head == NULL) || (v < head->data)){
                push(&head, v);
                size++;
            }else{
                Node* search = head;
                
                while(search->next != NULL){
                    if(v <= search->next->data){                       
                        addNode(search, v);                      
                        size++;
                        break;
                    }
                    search = search->next;
                }                
                if((v >= search->data) && (search->next == NULL)){
                    Node* newNode = (Node*)malloc(sizeof(Node));
                    newNode->data = v;
                    newNode->next = NULL;
                    search->next = newNode;
                    size++;
                }                   
            }           
        }else if(c == 'd'){           
            Node* traverse = head;

            while(traverse != NULL){
                if(traverse->data == v){
                   delete(&head, v);
                   size--;
                   break;                   
                }
                traverse = traverse->next;
            }                                 
        }              
    }

    printf("%d\n", size);    
    Node* printNode = head;    
    while(printNode != NULL){
        while((printNode->next != NULL) && (printNode->data == printNode->next->data)){
            printNode = printNode->next;
        }        
        printf("%d\t", printNode->data);      
        printNode = printNode->next;       
    }
    printf("\n");

Node* tmp;
    
while(head != NULL){
     tmp = head;      
     head = head->next;
     free(tmp);      
}
   
fclose(f1);
    
}
