#include <stdio.h>
#include <stdlib.h>

void swap(int* x, int* y){
    int temp = *x;
    *x = *y;
    *y = temp;
}

void sortAscending(int arr[], int s){
    int i, j;
    int min = 0;
    
    for(i = 0; i < s - 1; i++){
        min = i;
        for(j = i + 1; j < s; j++){
            if(arr[j] < arr[min])
                min = j;
        }
        if(min > i)
            swap(&arr[i], &arr[min]);
    }
}


void sortDescending(int arr[], int s){
    int i, j;
    int max = 0;
    
    for(i = 0; i < s - 1; i++){
        max = i;
        for(j = i + 1; j < s; j++){
            if(arr[j] > arr[max])
                max = j;
        }
        if(max > i)
            swap(&arr[i], &arr[max]);
    }
}


int main(int argc, char* argv[])
{
  FILE* f1 = fopen(argv[1], "r");
  
  if(f1 == NULL){
    printf("error\n");
    exit(0);
  }

  int size;
  fscanf(f1, "%d", &size);

  int evenArray[size];
  int oddArray[size];
  int evenIndex = 0;
  int oddIndex = 0;
  int index = 0;
  
  while(index < size){
     int n;
     fscanf(f1, "%d", &n);
     if(n % 2 == 0){
        evenArray[evenIndex] = n;
        evenIndex++;
     }else{
        oddArray[oddIndex] = n;
        oddIndex++;
     }
     index++;
  }

  sortAscending(evenArray, evenIndex);
  sortDescending(oddArray, oddIndex);

  int c;
  for(c = 0; c < evenIndex; c++){
      printf("%d\t", evenArray[c]);
  }

  for(c = 0; c < oddIndex; c++){
      printf("%d\t", oddArray[c]);
  }
  printf("\n");
  
  fclose(f1);
}
