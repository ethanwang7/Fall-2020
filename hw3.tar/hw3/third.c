#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int get(unsigned short x, int n){
    x = x & (1 << n);
    if(x == 0){
         return 0;
    }else{
         return 1;
    }
}

unsigned short flip(unsigned short n){
    unsigned short r = 0;
    int i = 0;
    while(i < (sizeof(r)*8)){
        r = r << 1;
        
        if(get(n, i) == 1){
            r = r ^ 1;
        }
        i++;
    }
    return r;
}

int main(int argc, char* argv[])
{
    unsigned short x = atoi(argv[1]);
    unsigned short reverse = flip(x);

    if(reverse == x){
        printf("Is-Palindrome\n");
    }else{
        printf("Not-Palindrome\n");
    }    
}
