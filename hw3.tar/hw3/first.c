#include <stdio.h>
#include <string.h>

unsigned short set(unsigned short x, int n, int v){
    return (x & (~(1 << n))) | (v << n);
}

unsigned short comp(unsigned short x, int n){
    return x ^ (1 << n);
}

int get(unsigned short x, int n){
    x = x & (1 << n);
    if(x == 0){
        return 0;
    }else{
        return 1;
    }
}

int main(int argc, char* argv[])
{
    FILE* f1 = fopen(argv[1], "r");
    unsigned short x;
    fscanf(f1, "%hu\n", &x);   
    
    while(1){
        char s[5];
        int n;
        int discard;
        int temp = fscanf(f1, "%s\t", s);
        if(temp != 1){
            break;
        }
        
        if(strcmp(s, "set") == 0){            
            int v;
            fscanf(f1, "%d\t", &n);
            fscanf(f1, "%d\n", &v);            
            x = set(x, n, v);
            printf("%hu\n", x);
        }else if(strcmp(s, "comp") == 0){
            fscanf(f1, "%d\t", &n);
            fscanf(f1, "%d\n", &discard);
            x = comp(x, n);
            printf("%hu\n", x);
        }else if(strcmp(s, "get") == 0){
            fscanf(f1, "%d\t", &n);
            fscanf(f1, "%d\n", &discard);
            printf("%d\n", get(x, n));
        }       
    }

    fclose(f1);
}
