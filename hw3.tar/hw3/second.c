#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[])
{
    unsigned short x = atoi(argv[1]);
    int parity = 0;
    int possiblePair = 0;
    int pairs = 0;

    while (x > 0){
        if((x & 1) == 1){
            parity++;
            if(possiblePair != 0){
                pairs++;
                possiblePair = 0;
            }else{
                possiblePair++;
            }
        }else{
            possiblePair = 0;
        }
        x = x >> 1;
    }
    if(parity % 2 == 0){
        printf("Even-Parity\t");
    }else{
        printf("Odd-Parity\t");
    }

    printf("%d\n", pairs);
}
